package com.example.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private Handler handler;
    private Runnable shutdownRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView webView = findViewById(R.id.webview);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);  // JavaScriptを有効化

        TextView parameterTextView = findViewById(R.id.parameter);

        Intent intent = getIntent();
        String action = intent.getAction();
        Uri data = intent.getData();

        BottomNavigationView bottomNav = findViewById(R.id.bottomNavigationView);

        if (Intent.ACTION_VIEW.equals(action) && data != null) {
            String parameter = data.getLastPathSegment();
            parameterTextView.setText("Parameter: " + parameter);

            Map<String, String> urlMap = new HashMap<>();
            urlMap.put("123", "http://example.com");
            urlMap.put("456", "file:///android_asset/YouTube.html");
            urlMap.put("789", "file:///android_asset/example_com.html");

            String url = urlMap.get(parameter);
            if (url != null) {
                webView.loadUrl(url);
                bottomNav.setSelectedItemId(R.id.viewer);  // viewerタブを選択する
            }
        }

        handler = new Handler();
        shutdownRunnable = new Runnable() {
            @Override
            public void run() {
                finishAndRemoveTask();
            }
        };

        LinearLayout header = findViewById(R.id.header);
        header.setBackgroundColor(Color.parseColor("#FF5733"));

        bottomNav.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.viewer:
                    // Viewer選択時はWebViewを表示し、フレームレイアウトを非表示にする
                    findViewById(R.id.webview).setVisibility(View.VISIBLE);
                    findViewById(R.id.fragment_container).setVisibility(View.GONE);
                    return true;
                case R.id.settings:
                    // Settings選択時はWebViewを非表示にし、フレームレイアウトにSettingsFragmentを表示
                    findViewById(R.id.webview).setVisibility(View.GONE);
                    findViewById(R.id.fragment_container).setVisibility(View.VISIBLE);
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, new SettingsFragment())
                            .commit();
                    return true;
                default:
                    return false;
            }
        });
    }


    @Override
    protected void onPause() {
        super.onPause();
        handler.postDelayed(shutdownRunnable, 10 * 60 * 1000);  // 10分後にシャットダウン
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(shutdownRunnable);  // シャットダウンタスクをキャンセル
    }
}
