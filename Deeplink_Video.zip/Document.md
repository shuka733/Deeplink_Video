# アプリケーションドキュメンテーション

- [アプリケーションドキュメンテーション](#アプリケーションドキュメンテーション)
- [デモの手順](#デモの手順)
- [ソースコードの概要説明](#ソースコードの概要説明)
    - [1. `index.html`(Webページ用)](#1-indexhtmlwebページ用)
    - [2. `activity_main.xml`(src/main/res/layout)](#2-activity_mainxmlsrcmainreslayout)
    - [3. `bottom_nav_menu.xml`(src/main/res/menu)](#3-bottom_nav_menuxmlsrcmainresmenu)
    - [4. `fragment_settings.xml`(src/main/res/layout)](#4-fragment_settingsxmlsrcmainreslayout)
    - [5. `MainActivity.java`(src/main/java/com/example/app)](#5-mainactivityjavasrcmainjavacomexampleapp)
    - [6. `SettingsFragment.java`(src/main/java/com/example/app)](#6-settingsfragmentjavasrcmainjavacomexampleapp)
    - [7. `AndroidManifest.xml`(src/main/res)](#7-androidmanifestxmlsrcmainres)
    - [8. `YouTube.html`と`example_com.html`(src/main/assets)](#8-youtubehtmlとexample_comhtmlsrcmainassets)
- [ソースコードの詳細説明](#ソースコードの詳細説明)
  - [1. `index.html`](#1-indexhtml)
    - [ヘッダー部分](#ヘッダー部分)
    - [CSSスタイルシート](#cssスタイルシート)
    - [本文とディープリンク](#本文とディープリンク)
    - [アプリインストールバナー](#アプリインストールバナー)
    - [JavaScriptコード](#javascriptコード)
  - [2. `activity_main.xml`](#2-activity_mainxml)
    - [ヘッダー部分](#ヘッダー部分-1)
    - [パラメータ表示部分](#パラメータ表示部分)
    - [フラグメント表示コンテナ](#フラグメント表示コンテナ)
    - [WebView部分](#webview部分)
    - [ボトムナビゲーション部分](#ボトムナビゲーション部分)
  - [3. `bottom_nav_menu.xml`](#3-bottom_nav_menuxml)
    - [メニューアイテム: ビューア](#メニューアイテム-ビューア)
    - [メニューアイテム: 設定](#メニューアイテム-設定)
  - [4. `fragment_settings.xml`](#4-fragment_settingsxml)
    - [ルート要素: `LinearLayout`](#ルート要素-linearlayout)
    - [テキストビュー: バージョン情報](#テキストビュー-バージョン情報)
    - [エディットテキスト: フリーテキスト入力](#エディットテキスト-フリーテキスト入力)
  - [5. `MainActivity.java`](#5-mainactivityjava)
    - [パッケージ宣言](#パッケージ宣言)
    - [インポート宣言](#インポート宣言)
    - [クラス宣言](#クラス宣言)
    - [インスタンス変数](#インスタンス変数)
    - [onCreateメソッド](#oncreateメソッド)
      - [5.1. 基本的な初期化](#51-基本的な初期化)
      - [5.2. WebViewの設定](#52-webviewの設定)
      - [5.3. パラメータ表示部分の初期化](#53-パラメータ表示部分の初期化)
      - [5.4. DeepLinkデータの取得](#54-deeplinkデータの取得)
      - [5.5. ボトムナビゲーションの初期化](#55-ボトムナビゲーションの初期化)
      - [5.6. DeepLinkの処理](#56-deeplinkの処理)
      - [5.7. シャットダウンの準備](#57-シャットダウンの準備)
      - [5.8. ヘッダー部分の設定](#58-ヘッダー部分の設定)
      - [5.9. ボトムナビゲーションのイベントリスナー](#59-ボトムナビゲーションのイベントリスナー)
    - [アクティビティのライフサイクルメソッド](#アクティビティのライフサイクルメソッド)
      - [5.11. `onPause()`](#511-onpause)
      - [5.12. `onResume()`](#512-onresume)
  - [6. `SettingsFragment`](#6-settingsfragment)
    - [クラスの概要](#クラスの概要)
    - [コンストラクタ](#コンストラクタ)
    - [`onCreateView` メソッド](#oncreateview-メソッド)
  - [7. `AndroidManifest.xml`](#7-androidmanifestxml)
    - [マニフェストの宣言](#マニフェストの宣言)
    - [インターネットのアクセス許可](#インターネットのアクセス許可)
    - [アプリケーション要素](#アプリケーション要素)
    - [メインアクティビティの宣言](#メインアクティビティの宣言)
    - [Intentフィルター](#intentフィルター)
    - [DeepLinkの設定](#deeplinkの設定)
  - [8. `YouTube.html と example_com.html`](#8-youtubehtml-と-example_comhtml)
    - [ドキュメントの宣言とヘッダー部分](#ドキュメントの宣言とヘッダー部分)
    - [スタイルの定義](#スタイルの定義)
    - [本文と動画の埋め込み](#本文と動画の埋め込み)
    - [`example_com.html`について](#example_comhtmlについて)

<div style="page-break-after: always;"></div>

# デモの手順

アプリケーションのデモを行う手順は以下の通りです。

1. 初めに、Webページの3つのDeepLinkのうちいずれかをタップし、APKファイルをダウンロードします。ここでは未インストール時にポップアップが表示されることを確認します。APKファイルは、Android Studioのプロジェクトからもダウンロードできます。事前に、デバイズ側の「不明なアプリのインストール」設定を許可しておいてください。
2. apkファイルからアプリをインストール後、Webページの3つのDeepLinkをタップし、それぞれが正常に動作することを確認します。
3. 設定ボタンとビューアボタンをタップし、正常に画面が遷移することを確認します。

<div style="page-break-after: always;"></div>

# ソースコードの概要説明

今回の成果物となるソースコードは、大きく8つです。各ファイルの詳細を以下に示します。ファイル名の後に、Android Studio内でどこのディレクトリに保存されているかを記載しています。

### 1. `index.html`(Webページ用)

このHTMLファイルはアプリケーションのデモ用のWebページを表しています。3つのDeepLink（`myapp://dda.io/view/file/123`、`myapp://dda.io/view/file/456`、`myapp://dda.io/view/file/789`）がそれぞれ異なるリンクとして記述されています。これらのリンクはアプリケーションがインストールされていない場合に、APKファイルのダウンロードリンクを表示するポップアップを表示します。

### 2. `activity_main.xml`(src/main/res/layout)

このXMLファイルはアプリケーションのメイン画面のレイアウトを定義しています。WebView、表示するパラメータ、ファイルビューア、設定の各部分がレイアウトに含まれています。

### 3. `bottom_nav_menu.xml`(src/main/res/menu)

アプリのボトムナビゲーションメニューの項目を定義するXMLファイル。ビューアと設定の2つのメニューアイテムが含まれています。

### 4. `fragment_settings.xml`(src/main/res/layout)

アプリ内の「設定」セクションのレイアウトを定義するXMLファイル。アプリのバージョン情報とフリーテキスト入力欄を表示するためのレイアウトが含まれています。

### 5. `MainActivity.java`(src/main/java/com/example/app)

このJavaファイルはアプリケーションのメインアクティビティを定義しています。ここではDeepLinkからのパラメータを取得し、対応するURLをWebViewにロードします。また、アプリがバックグラウンドに移行してから10分後にアプリを自動的に終了する機能も実装されています。

### 6. `SettingsFragment.java`(src/main/java/com/example/app)

アプリの設定画面を表示するフラグメントのJavaファイル。レイアウトは`fragment_settings.xml`によって定義されています。


### 7. `AndroidManifest.xml`(src/main/res)

このXMLファイルはアプリケーションの基本的な設定とDeepLinkの設定を含んでいます。`<data>`タグ内の属性`android:host`、`android:scheme`、`android:pathPrefix`によりDeepLinkの形式が定義されています。

### 8. `YouTube.html`と`example_com.html`(src/main/assets)

これらのHTMLファイルはそれぞれ、YouTubeの動画と`example.com`のWebページを表示するためのiframeを含んでいます。これらのファイルはアプリケーション内部でローカルに保存され、DeepLinkからのパラメータにより特定のURLをWebViewにロードします。

<div style="page-break-after: always;"></div>

# ソースコードの詳細説明

## 1. `index.html`
---

### ヘッダー部分

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Deep Link</title>
```

この部分はHTML文書の宣言（`<!DOCTYPE html>`）と、基本的なメタデータ（文字コード、ページタイトル）を設定する`<head>`セクションです。

### CSSスタイルシート

```html
<style>
    #app-banner {
        display: none;
        position: fixed;
        bottom: 0;
        width: 100%;
        background-color: lightgrey;
        padding: 10px;
        text-align: center;
    }
</style>
```

これは内部CSSスタイルシートで、IDが"app-banner"のHTML要素（後述の`<div id="app-banner">`）のスタイルを定義しています。初期状態では非表示（`display: none;`）で、固定位置（画面の下部）に配置されます。

### 本文とディープリンク

```html
</head>
<body>
    <p><a class="deep-link" href="myapp://dda.io/view/file/123">example.comのWebページ</a></p>
    <p><a class="deep-link" href="myapp://dda.io/view/file/456">Youtubeサンプル動画</a></p>
    <p><a class="deep-link" href="myapp://dda.io/view/file/789">example.comのWebページ(iframe)</a></p>
```

この部分は本文（`<body>`）の開始で、3つのパラグラフ（`<p>`）があります。各パラグラフには、`myapp://`スキームで始まるディープリンクを指すリンク（`<a>`）が含まれています。

### アプリインストールバナー

```html
<div id="app-banner">
    <p>Install our app for a better experience!</p>
    <a href="https://github.com/shuka733/Deeplinktest/raw/main/app-debug.apk" download>Install App</a>
</div>
```

この部分は、アプリをインストールするためのバナーを含む`<div>`要素です。初期状態では非表示になっていますが、ディープリンクをクリックした後でアプリが未インストールの場合に表示されます。バナーには、アプリのapkファイルへの直接リンクが含まれています。

### JavaScriptコード

```html
<script>
    var deepLinks = document.querySelectorAll('.deep-link');
    deepLinks.forEach(function(deepLink) {
        deepLink.addEventListener('click', function(event) {
            event.preventDefault();
            var clickedLink = this.href;
            window.location.href = clickedLink;
            setTimeout(function() {
                if(document.hasFocus()) {
                    document.getElementById('app-banner').style.display = 'block';
                }
            }, 1000);
        });
    });
</script>
```

この部分はJavaScriptコードで、ディープリンクのクリックイベントをハンドルします。各ディープリンクに対して、クリックイベントが発生したときの動作を定義しています。具体的には、ディープリンクをクリックした後に、1秒待ってからアプリが未インストールの場合にバナーを表示します。

<div style="page-break-after: always;"></div>

## 2. `activity_main.xml`
---

このレイアウトは、アプリケーションのメイン画面の基盤となるレイアウトです。内部の各要素はこのレイアウトの上に配置されます。

### ヘッダー部分

```xml
<LinearLayout
    android:id="@+id/header"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:background="#000000"
    android:orientation="vertical"
    android:padding="16dp">

    <TextView
        android:id="@+id/fileViewer"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="@string/header_title"
        android:textSize="20sp" />
</LinearLayout>
```

この部分はアプリケーションのヘッダーを表示するためのレイアウトです。"ファイルビューア"というテキストが中央に表示されます。

### パラメータ表示部分

```xml
<TextView
    android:id="@+id/parameter"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:layout_below="@id/header"
    android:text="Parameter: "
    android:textSize="20sp" />
```

この部分は、DeepLinkから受け取ったパラメータを表示するためのテキストビューです。

### フラグメント表示コンテナ

```xml
<FrameLayout
    android:id="@+id/fragment_container"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:layout_above="@+id/bottomNavigationView"
    android:layout_below="@id/parameter" />
```

この部分は、異なるフラグメントを表示するためのコンテナとして機能するフレームレイアウトです。

### WebView部分

```xml
<WebView
    android:id="@+id/webview"
    android:layout_width="match_parent"
    android:layout_height="0dp"
    android:layout_above="@+id/bottomNavigationView"
    android:layout_below="@id/parameter" />
```

この部分は、Webページを表示するためのWebViewです。DeepLinkからのパラメータに応じて、異なるURLがロードされます。

### ボトムナビゲーション部分

```xml
<com.google.android.material.bottomnavigation.BottomNavigationView
    android:id="@+id/bottomNavigationView"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:layout_alignParentBottom="true"
    app:menu="@menu/bottom_nav_menu" />
```

この部分は、アプリケーションの下部に配置されるボトムナビゲーションビューです。"ビューア"と"設定"という2つのメニューアイテムを持っています。

<div style="page-break-after: always;"></div>

## 3. `bottom_nav_menu.xml` 
---

このXMLファイルは、アプリケーションのボトムナビゲーションメニューのアイテムを定義しています。

### メニューアイテム: ビューア

```xml
<item
    android:id="@+id/viewer"
    android:title="@string/nav_viewer"
    app:showAsAction="ifRoom" />
```

- `android:id`: このアイテムのIDとして`viewer`を指定しています。これにより、Javaコード側からこのアイテムを識別・操作できます。
- `android:title`: このアイテムの表示名としてリソース文字列`@string/nav_viewer`（"ビューア"）を使用しています。
- `app:showAsAction`: このアイテムがアクションバーの中に表示される条件を指定しています。`ifRoom`はスペースがある場合にのみアクションバーに表示することを意味します。ボトムナビゲーションにおいては通常は無視されますが、一般的なメニューにおいてはこの属性が役立ちます。

### メニューアイテム: 設定

```xml
<item
    android:id="@+id/settings"
    android:title="@string/nav_settings"
    app:showAsAction="ifRoom" />
```

- `android:id`: このアイテムのIDとして`settings`を指定しています。
- `android:title`: このアイテムの表示名としてリソース文字列`@string/nav_settings`（"設定"）を使用しています。
- `app:showAsAction`: 同様に、このアイテムがアクションバーの中に表示される条件を指定しています。

<div style="page-break-after: always;"></div>

## 4. `fragment_settings.xml`
---

このXMLファイルは、アプリケーションの設定画面のレイアウトを定義しています。

### ルート要素: `LinearLayout`

```xml
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="16dp">
```

- `android:orientation`: 子要素を垂直方向に並べるために`vertical`を指定しています。
- `android:padding`: すべての側面に16dpのパディングを追加しています。これにより、子要素が端に接触しないようになります。

### テキストビュー: バージョン情報

```xml
<TextView
    android:id="@+id/versionInfo"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:text="@string/version_info"
    android:textSize="20sp" />
```

- `android:id`: このテキストビューのIDとして`versionInfo`を指定しています。
- `android:text`: テキストビューの内容としてリソース文字列`@string/version_info`を表示しています。
- `android:textSize`: テキストのサイズとして20spを指定しています。

### エディットテキスト: フリーテキスト入力

```xml
<EditText
    android:id="@+id/editableText"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:hint="Enter text here..."
    android:layout_marginTop="16dp"/>
```

- `android:id`: このエディットテキストのIDとして`editableText`を指定しています。
- `android:hint`: ユーザーが何も入力していないときに表示されるヒントテキストとして"Enter text here..."を指定しています。
- `android:layout_marginTop`: 上側に16dpのマージンを追加しています。

このレイアウトは設定画面を表しており、バージョン情報を表示するテキストビューと、フリーテキストを入力するためのエディットテキストが含まれています。

<div style="page-break-after: always;"></div>

## 5. `MainActivity.java`
---

### パッケージ宣言

```java
package com.example.app;
```

この行は、このJavaクラスが所属するパッケージを宣言しています。`com.example.app`はアプリケーションの名前空間を示しており、このパッケージの中には`MainActivity`の他にもいくつかのクラスやリソースが含まれている可能性があります。

### インポート宣言

以下の部分は、このクラスで使用する外部のクラスやインターフェースをインポートするための宣言です。

```java
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.HashMap;
import java.util.Map;
```

- `androidx.*`: AndroidXライブラリからのクラスやインターフェース。特に、FragmentやAppCompatActivityなどのUI関連のクラスをインポートしています。
- `android.*`: Androidフレームワークの基本的なクラスやインターフェース。`Intent`, `Color`, `Uri`などの基本的なクラスやリソースに関連するクラスをインポートしています。
- `com.google.android.material.bottomnavigation.BottomNavigationView`: GoogleのMaterial Designライブラリからボトムナビゲーションビューをインポートしています。
- `java.util.*`: Javaの基本ライブラリからマップ関連のクラスをインポートしています。

これらのインポート宣言により、ソースコード内でこれらのクラスやインターフェースを完全修飾名を使用せずに参照することができます。

### クラス宣言

```java
public class MainActivity extends AppCompatActivity {
```

この行は、`MainActivity`という名前の新しいクラスを宣言しています。このクラスは`AppCompatActivity`というクラスを継承しており、これによってアクティビティの基本的な機能を持つことができます。

### インスタンス変数

```java
private Handler handler;
private Runnable shutdownRunnable;
```

これらはクラスのプライベートインスタンス変数であり、`MainActivity`内でのみアクセスできます。`Handler`はUIスレッドでの処理をスケジュールするためのクラス、`Runnable`は実行可能なコードの単位を表すインターフェースです。

### onCreateメソッド

`onCreate`はAndroidのアクティビティライフサイクルにおいて最初に呼ばれるメソッドです。このメソッド内で、UIの初期化やデータの取得、イベントリスナーの設定など、アクティビティの初期設定が行われます。

#### 5.1. 基本的な初期化

```java
super.onCreate(savedInstanceState);
setContentView(R.layout.activity_main);
```

上記のコードでは、`super.onCreate()`を通して親クラスの`onCreate`メソッドを呼び出し、続いて`setContentView`メソッドでUIのレイアウトを設定しています。

#### 5.2. WebViewの設定

```java
WebView webView = findViewById(R.id.webview);
WebSettings webSettings = webView.getSettings();
webSettings.setJavaScriptEnabled(true);
```

上記のコードでは、`findViewById`メソッドを使用して`WebView`のインスタンスを取得し、JavaScriptを有効にしています。これにより、WebView内でJavaScriptのコードが実行できるようになります。

#### 5.3. パラメータ表示部分の初期化

```java
TextView parameterTextView = findViewById(R.id.parameter);
```

この行では、`activity_main.xml`で定義された`TextView`（ID: parameter）のインスタンスを取得しています。この`TextView`は、DeepLinkから取得したパラメータを表示するための部分です。

#### 5.4. DeepLinkデータの取得

```java
Intent intent = getIntent();
String action = intent.getAction();
Uri data = intent.getData();
```

この部分で、アクティビティが開始されたときの`Intent`を取得しています。この`Intent`から、アクションやデータ（DeepLinkのURL）を取得しています。

#### 5.5. ボトムナビゲーションの初期化

```java
BottomNavigationView bottomNav = findViewById(R.id.bottomNavigationView);
```

ここでは、`activity_main.xml`で定義されたボトムナビゲーション（ID: bottomNavigationView）のインスタンスを取得しています。

#### 5.6. DeepLinkの処理

```java
if (Intent.ACTION_VIEW.equals(action) && data != null) {
            String parameter = data.getLastPathSegment();
            parameterTextView.setText("Parameter: " + parameter);

            Map<String, String> urlMap = new HashMap<>();
            urlMap.put("123", "http://example.com");
            urlMap.put("456", "file:///android_asset/YouTube.html");
            urlMap.put("789", "file:///android_asset/example_com.html");

            String url = urlMap.get(parameter);
            if (url != null) {
                webView.loadUrl(url);
                bottomNav.setSelectedItemId(R.id.viewer);  // viewerタブを選択する
            }
        }
```

この条件分岐内では、アクションが`ACTION_VIEW`であり、データがnullでない場合にDeepLinkの処理を行っています。具体的には、DeepLinkの最後のセグメントを取得し、それをキーとしてURLをマッピングしています。対応するURLが存在すれば、そのURLをWebViewでロードします。
- 123はhttp://example.comという外部のWebページに対応しています。このURLは、通常のWebページとして直接WebViewにロードされます。
- 456はfile:///android_asset/YouTube.htmlというアプリケーションのローカルアセットにあるHTMLファイルに対応しています。このHTMLファイルには、YouTubeの動画を表示するためのiframeが含まれています。
- 789はfile:///android_asset/example_com.htmlという別のローカルアセットにあるHTMLファイルに対応しています。このHTMLファイルもiframeを使用してexample.comのWebページを表示します。

このように、アプリ内部のローカルアセットに保存されているHTMLファイルを使用することで、特定の内容をiframeで表示することが可能です。これにより、アプリ内部で独自の表示内容や動作を持たせることができます。

#### 5.7. シャットダウンの準備

```java
handler = new Handler();
shutdownRunnable = new Runnable() {
    @Override
    public void run() {
        finishAndRemoveTask();
    }
};
```

この部分で、アプリがバックグラウンドに移行した後のシャットダウンのための`Handler`と`Runnable`を用意しています。`finishAndRemoveTask`メソッドは、アクティビティを終了し、最近のタスクリストからも削除します。

#### 5.8. ヘッダー部分の設定

```java
LinearLayout header = findViewById(R.id.header);
header.setBackgroundColor(Color.parseColor("#FF5733"));
```

ここでは、`activity_main.xml`で定義されたヘッダー部分の`LinearLayout`（ID: header）のインスタンスを取得し、背景色を`#FF5733`に設定しています。

#### 5.9. ボトムナビゲーションのイベントリスナー

```java
bottomNav.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.viewer:
                    // Viewer選択時はWebViewを表示し、フレームレイアウトを非表示にする
                    findViewById(R.id.webview).setVisibility(View.VISIBLE);
                    findViewById(R.id.fragment_container).setVisibility(View.GONE);
                    return true;
                case R.id.settings:
                    // Settings選択時はWebViewを非表示にし、フレームレイアウトにSettingsFragmentを表示
                    findViewById(R.id.webview).setVisibility(View.GONE);
                    findViewById(R.id.fragment_container).setVisibility(View.VISIBLE);
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, new SettingsFragment())
                            .commit();
                    return true;
                default:
                    return false;
            }
        });
```

この部分では、ボトムナビゲーションの各アイテムが選択されたときの動作を定義しています。選択されたアイテムのIDに応じて、WebViewの表示やフラグメントの表示を切り替えています。

了解しました。指定されたコードの説明を以下に示します。

### アクティビティのライフサイクルメソッド

#### 5.11. `onPause()`

```java
@Override
protected void onPause() {
    super.onPause();
    handler.postDelayed(shutdownRunnable, 10 * 60 * 1000);  // 10分後にシャットダウン
}
```

この`onPause()`メソッドは、アクティビティがバックグラウンドに移動する（例：他のアプリを開く、ホーム画面に戻るなど）ときに呼ばれます。メソッド内では、`handler.postDelayed`を使って、10分後にアプリをシャットダウンするタスク（`shutdownRunnable`）をスケジュールしています。この挙動は、アプリがバックグラウンドに移動してから10分後に自動で終了するためのものです。

#### 5.12. `onResume()`

```java
@Override
protected void onResume() {
    super.onResume();
    handler.removeCallbacks(shutdownRunnable);  // シャットダウンタスクをキャンセル
}
```

この`onResume()`メソッドは、アクティビティがフォアグラウンドに戻る（例：ユーザーが再度アプリを開く、他のアプリから戻るなど）ときに呼ばれます。メソッド内では、以前にスケジュールされたシャットダウンタスク（`shutdownRunnable`）をキャンセルしています。これにより、ユーザーがアプリを再度アクティブにした場合、自動で終了するタイマーがリセットされます。

これらのメソッドは、アプリのライフサイクルとユーザーの操作に応じて、特定のタスクを実行するためのものです。

<div style="page-break-after: always;"></div>

## 6. `SettingsFragment`
---

`SettingsFragment`は、設定画面を表示するためのフラグメントであり、UIのレイアウトは`fragment_settings.xml`ファイルに定義されています。このクラスはシンプルですが、アプリケーションの設定や情報を表示するための基本的な機能を持っています。

### クラスの概要

```java
public class SettingsFragment extends Fragment {
```

このクラスは、`Fragment`クラスを拡張することで、アプリケーション内の設定画面部分を表しています。

### コンストラクタ

```java
// コンストラクタ
public SettingsFragment() {
    // Required empty public constructor
}
```

`SettingsFragment`の公開コンストラクタです。フラグメントのインスタンス生成時に呼び出されるものの、特に何もしていません。フラグメントには公開のデフォルトコンストラクタが必要とされるため、これが用意されています。

### `onCreateView` メソッド

```java
@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container,
                         Bundle savedInstanceState) {
    // このフラグメントのレイアウトをインフレートする
    return inflater.inflate(R.layout.fragment_settings, container, false);
}
```

この`onCreateView`メソッドは、フラグメントのUI部分が初めて描画される際にシステムから呼び出されます。メソッド内では、`LayoutInflater`を使用して、`fragment_settings.xml`というリソースファイルに定義されたレイアウトをインフレート（ロード）しています。その後、このインフレートされたビューがメソッドから返され、フラグメントのUIとして表示されます。

<div style="page-break-after: always;"></div>

## 7. `AndroidManifest.xml`
---

### マニフェストの宣言

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.app">
```

これは、アプリケーションのマニフェストファイルの開始部分です。`xmlns:android`属性は、Android固有のXML要素と属性を使用できるようにするための名前空間を定義しています。`package`属性は、アプリケーションのパッケージ名を指定しています。

### インターネットのアクセス許可

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

この行は、アプリケーションがインターネットアクセスの権限を持っていることを宣言しています。この許可は、アプリケーションがWebページやAPIなどの外部リソースにアクセスするために必要です。

### アプリケーション要素

```xml
<application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.App"
        android:usesCleartextTraffic="true">
```

この`<application>`要素は、アプリケーション全体の設定やコンポーネントを定義するための要素です。属性`android:usesCleartextTraffic="true"`は、アプリがHTTPなどの明文トラフィックを許可するかどうかを定義しています。

### メインアクティビティの宣言

```xml
<activity
    android:name=".MainActivity"
    android:exported="true">
    ...
</activity>
```

この`<activity>`要素は、アプリケーションのメインアクティビティを宣言しています。`android:name`属性は、アクティビティのクラス名を指定しています。`android:exported="true"`は、他のアプリからこのアクティビティを起動できるようにするためのものです。

### Intentフィルター

```xml
<intent-filter>
    ...
</intent-filter>
```

`<intent-filter>`要素は、アクティビティがどのようなインテントに応答できるかを定義します。このアプリには2つのIntentフィルターがあり、一つはアプリの起動用、もう一つはDeepLinkのためのものです。

### DeepLinkの設定

```xml
<data
    android:host="dda.io"
    android:scheme="myapp"
    android:pathPrefix="/view/file/" />
```

この`<data>`要素は、DeepLinkの形式を定義しています。具体的には、このアプリは`myapp://dda.io/view/file/`という形式のDeepLinkを処理できることを示しています。

<div style="page-break-after: always;"></div>

## 8. `YouTube.html と example_com.html`
---

これらのHTMLファイルは、アプリケーション内部でローカルに保存されているもので、アプリのWebViewで表示する際のコンテンツとして利用されます。

### ドキュメントの宣言とヘッダー部分

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>YouTube Video</title>
```

この部分は、HTML文書の宣言（`<!DOCTYPE html>`）と、基本的なメタデータ（文字コード、ページタイトル）を設定する`<head>`セクションです。

### スタイルの定義

```html
<style>
    html, body {
        height: 100%;
        margin: 0;
        padding: 0;
        background-color: #000;
    }
    .video-container {
        position: relative;
        height: 100%;
    }
    .video-container iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
    }
</style>
```

この内部CSSスタイルシートは、ページ全体の背景色やiframeの動画の位置、サイズを定義しています。具体的には、動画がページ全体をカバーするように設定されています。

### 本文と動画の埋め込み

```html
<body>
<div class="video-container">
    <iframe src="https://www.youtube.com/embed/bjmBJ1Fl0cs?autoplay=1" frameborder="0" allowfullscreen></iframe>
</div>
</body>
```

この部分は、本文（`<body>`）の開始で、YouTubeの動画を埋め込む`<iframe>`が含まれています。動画は自動再生モードで、フルスクリーンモードも許可されています。

### `example_com.html`について

`example_com.html`は、基本的な構造とスタイルが`YouTube.html`と同一です。唯一の違いは、`<iframe>`の`src`属性が`https://www.youtube.com/embed/bjmBJ1Fl0cs?autoplay=1`から`http://example.com`に変更されている点です。このことから、`example_com.html`は`http://example.com`のページ内容を埋め込むためのものとして機能します。
